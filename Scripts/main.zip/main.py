bl_info = {
    "name": "Shapeshifter",
    "author": "Fabio Gouveia Silva",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Monster",
    "description": "Monster Blender",
    "warning": "",
    "doc_url": "",
    "category": "",
}
# -----------------------------------------------------------------------------
import logic
import library
# -----------------------------------------------------------------------------
import bpy
from random import randint
from bpy.types import (Panel, Operator)
from bpy.utils import register_class, unregister_class
from pathlib import Path
import mathutils
# -----------------------------------------------------------------------------
def main(context):
    logic.constructor()
# -----------------------------------------------------------------------------
class Generate(bpy.types.Operator):
    """Generate New Creature"""
    bl_idname = "monster.shapeshifter"
    bl_label = "Generate New Creature"

    def execute(self, context):
        main(context)
        return {'FINISHED'}

class CustomPanel(bpy.types.Panel):
    bl_label = "Shapeshifter"
    bl_idname = "OBJECT_PT_blender"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Shapeshifter"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.operator(Generate.bl_idname, text="Blend", icon='RNA')

class SubPanel(bpy.types.Panel):
    bl_label = "Add to Library"
    bl_idname = "OBJECT_PT_subpanel"
    bl_parent_id = "OBJECT_PT_blender"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Shapeshifter"
    def draw(self, context):
        layout = self.layout
        # Add a text input field for the user to enter a name
        layout.prop(context.scene, "library_name")
        # Add a button to submit the input text to the addLibrary() function
        layout.operator("monster.add_to_library", text="Add to Library")

class AddToLibrary(bpy.types.Operator):
    bl_idname = "monster.add_to_library"
    bl_label = "Add to Library"

    def execute(self, context):
        name = context.scene.library_name
        object = bpy.context.object
        print("NOICE")
        print(object, name)
        library.addLibrary(object, name)
        return {'FINISHED'}
# -----------------------------------------------------------------------------
# Classes to register
_classes = [
    Generate,
    CustomPanel,
    SubPanel,
    AddToLibrary
]
# -----------------------------------------------------------------------------
# Register and unregister functions
def register():
    for cls in _classes:
        register_class(cls)
    bpy.types.Scene.library_name = bpy.props.StringProperty(name="Name")

def unregister():
    del bpy.types.Scene.library_name
    for cls in reversed(_classes):
        unregister_class(cls)

if __name__ == "__main__":
    register()
